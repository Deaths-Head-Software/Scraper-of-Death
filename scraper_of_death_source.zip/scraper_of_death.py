#!/usr/bin/env python3
"""
Scraper of Death - Advanced Web Scraping Tool
Death's Head Software
"""

from __future__ import annotations

import sys
import json
import csv
import time
import re
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from urllib.parse import urlparse, urljoin

# --- PyQt6 Imports ---
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QTimer, QSize, QUrl
)
from PyQt6.QtGui import (
    QFont, QColor, QPalette, QIcon, QTextCursor, QAction, QPainter, QPixmap
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QComboBox, QSpinBox,
    QTabWidget, QGroupBox, QCheckBox, QTableWidget, QTableWidgetItem,
    QFileDialog, QMessageBox, QProgressBar, QSplitter, QHeaderView,
    QMenu, QMenuBar, QStatusBar, QFrame, QSplashScreen, QSizePolicy,
    QScrollArea
)

# --- Third-party Imports ---
try:
    import requests
    from bs4 import BeautifulSoup
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.options import Options as ChromeOptions
    from selenium.webdriver.chrome.service import Service
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False

try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

# playwright-stealth 2.x replaced stealth_sync with the Stealth class.
# Import it and create a shared instance used by _scrape_with_playwright.
try:
    from playwright_stealth import Stealth as _StealthClass
    _stealth_instance = _StealthClass()
    PLAYWRIGHT_STEALTH = True
except Exception as _stealth_err:
    PLAYWRIGHT_STEALTH = False
    _stealth_instance = None
    _STEALTH_ERROR = str(_stealth_err)

# =============================================================================
# Global Definitions
# =============================================================================

APP_NAME = "Scraper of Death"
ORG_NAME = "Death's Head Software"
VERSION = "1.0.0"

# Dark theme colors
DARK_BG = "#1a1a1a"
DARKER_BG = "#0d0d0d"
LIGHT_TEXT = "#e0e0e0"
GREEN_ACCENT = "#00ff00"
RED_ACCENT = "#ff0000"
GRAY_BORDER = "#333333"

# =============================================================================
# Helper Functions
# =============================================================================

def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller."""
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = Path(__file__).parent
    
    return Path(base_path) / relative_path

# =============================================================================
# Splash Screen Function
# =============================================================================

def create_splash():
    """
    Creates the QSplashScreen.

    It first checks for an external 'splash.png'. If not found, it generates
    a dark screen with the app name, org name, and ASCII skull art.
    """
    try:
        splash_path = resource_path("splash.png")
        
        if splash_path.exists():
            # Load external splash.png file
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback: Generate the dark-themed screen with ASCII art skull
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art): 
                painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# Scraper Thread
# =============================================================================

class ScraperThread(QThread):
    """Background thread for web scraping operations."""

    progress_update = pyqtSignal(str)
    scrape_complete = pyqtSignal(list)
    error_occurred  = pyqtSignal(str)

    def __init__(self, config: Dict[str, Any]):
        super().__init__()
        self.config  = config
        self._session: Optional[Any] = None   # requests.Session, closed on stop

    # ------------------------------------------------------------------
    # Public stop — called from the main thread via the STOP button
    # ------------------------------------------------------------------
    def stop(self):
        """Signal the thread to stop as soon as possible."""
        self.requestInterruption()          # QThread built-in flag
        if self._session is not None:
            try:
                self._session.close()       # aborts any in-flight request
            except Exception:
                pass

    def _stopped(self) -> bool:
        return self.isInterruptionRequested()

    # ------------------------------------------------------------------
    # Main run
    # ------------------------------------------------------------------
    def run(self):
        try:
            url               = self.config.get('url', '')
            method            = self.config.get('method', 'requests')
            selector_type     = self.config.get('selector_type', 'css')
            selector          = self.config.get('selector', '')
            use_headers       = self.config.get('use_headers', False)
            follow_links      = self.config.get('follow_links', False)
            max_depth         = self.config.get('max_depth', 1)
            delay             = self.config.get('delay', 0)
            proxy             = self.config.get('proxy', '')        # "host:port"
            proxy_type        = self.config.get('proxy_type', 'http')
            proxy_user        = self.config.get('proxy_user', '')
            proxy_pass        = self.config.get('proxy_pass', '')
            real_profile      = self.config.get('real_profile', False)
            chrome_profile_path = self.config.get('chrome_profile_path', '')

            self.progress_update.emit(f"Starting scrape of {url}...")

            if method == 'requests':
                results = self._scrape_with_requests(
                    url, selector_type, selector, use_headers,
                    proxy=proxy, proxy_type=proxy_type,
                    proxy_user=proxy_user, proxy_pass=proxy_pass
                )
            elif method == 'selenium' and SELENIUM_AVAILABLE:
                results = self._scrape_with_selenium(
                    url, selector_type, selector,
                    proxy=proxy, proxy_type=proxy_type,
                    real_profile=real_profile,
                    chrome_profile_path=chrome_profile_path
                )
            elif method == 'playwright' and PLAYWRIGHT_AVAILABLE:
                results = self._scrape_with_playwright(
                    url, selector_type, selector,
                    proxy=proxy, proxy_type=proxy_type,
                    proxy_user=proxy_user, proxy_pass=proxy_pass
                )
            else:
                raise Exception("Selected method not available — check dependencies")

            if self._stopped():
                self.progress_update.emit("Stopped.")
                self.scrape_complete.emit(results)
                return

            if follow_links and results:
                self.progress_update.emit(f"Following links (depth: {max_depth})...")
                results = self._follow_links(results, max_depth, delay)

            if self._stopped():
                self.progress_update.emit(f"Stopped. Collected {len(results)} items so far.")
            else:
                self.progress_update.emit(f"Scrape complete! Found {len(results)} items.")

            self.scrape_complete.emit(results)

        except Exception as e:
            if not self._stopped():
                self.error_occurred.emit(f"Scraping error: {str(e)}")
            else:
                self.progress_update.emit("Stopped.")
                self.scrape_complete.emit([])

    # ------------------------------------------------------------------
    # Requests-based scraping
    # ------------------------------------------------------------------
    def _make_session(self, use_headers: bool,
                      proxy: str = '', proxy_type: str = 'http',
                      proxy_user: str = '', proxy_pass: str = ''):
        """Create a requests.Session with optional stealth headers and proxy."""
        import requests as req
        session = req.Session()
        if use_headers:
            session.headers.update({
                'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'DNT':             '1',
                'Connection':      'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest':  'document',
                'Sec-Fetch-Mode':  'navigate',
                'Sec-Fetch-Site':  'none',
                'Sec-Fetch-User':  '?1',
            })
        if proxy:
            creds = f"{proxy_user}:{proxy_pass}@" if proxy_user else ""
            scheme = proxy_type.lower()     # http, https, socks5, socks5h
            proxy_url = f"{scheme}://{creds}{proxy}"
            session.proxies = {'http': proxy_url, 'https': proxy_url}
            self.progress_update.emit(f"Using proxy: {scheme}://{proxy}")
        self._session = session
        return session

    def _scrape_with_requests(self, url: str, selector_type: str, selector: str,
                               use_headers: bool, proxy: str = '',
                               proxy_type: str = 'http', proxy_user: str = '',
                               proxy_pass: str = '') -> List[Dict]:
        """Scrape using requests + BeautifulSoup."""
        if not REQUESTS_AVAILABLE:
            raise Exception("requests/beautifulsoup4 not installed")

        session = self._make_session(use_headers, proxy, proxy_type,
                                     proxy_user, proxy_pass)

        self.progress_update.emit(f"Fetching {url}...")
        response = session.get(url, timeout=15)
        response.raise_for_status()

        if self._stopped():
            return []

        self.progress_update.emit("Parsing HTML...")
        soup = BeautifulSoup(response.content, 'html.parser')

        results = []

        if selector_type == 'css':
            try:
                elements = soup.select(selector) if selector else []
            except Exception as css_err:
                hint = ""
                if selector.startswith(('http://', 'https://', 'www.')):
                    hint = "\n\nIt looks like you entered a URL instead of a CSS selector."
                raise Exception(
                    f"Invalid CSS selector: {selector!r}\n{css_err}{hint}"
                )
        elif selector_type == 'xpath':
            self.error_occurred.emit("XPath requires Selenium — switch to Selenium method.")
            return []
        elif selector_type == 'regex':
            pattern = re.compile(selector)
            for match in pattern.findall(response.text):
                results.append({
                    'content':   match,
                    'url':       url,
                    'timestamp': datetime.now().isoformat(),
                })
            return results
        else:
            elements = []

        for elem in elements:
            item = {
                'tag':       elem.name,
                'text':      elem.get_text(strip=True),
                'html':      str(elem),
                'url':       url,
                'timestamp': datetime.now().isoformat(),
            }
            for attr, value in elem.attrs.items():
                item[f'attr_{attr}'] = value
            results.append(item)

        return results

    # ------------------------------------------------------------------
    # Selenium-based scraping
    # ------------------------------------------------------------------
    def _scrape_with_selenium(self, url: str, selector_type: str, selector: str,
                               proxy: str = '', proxy_type: str = 'http',
                               real_profile: bool = False,
                               chrome_profile_path: str = '') -> List[Dict]:
        if not SELENIUM_AVAILABLE:
            raise Exception("Selenium not installed")

        options = ChromeOptions()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_argument('--log-level=3')
        options.add_argument('--window-size=1920,1080')
        options.add_argument(
            '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
        )

        if real_profile and chrome_profile_path:
            # Check for SingletonLock — Chrome writes this when the profile
            # is open. If present, launching ChromeDriver will crash.
            import os as _os
            lock_file = _os.path.join(chrome_profile_path, 'SingletonLock')
            if _os.path.exists(lock_file):
                raise Exception(
                    "user data directory is already in use — "
                    "close all Chrome windows and try again"
                )
            options.add_argument(f'--user-data-dir={chrome_profile_path}')
            options.add_argument('--profile-directory=Default')
            options.add_argument('--window-position=-2000,0')  # off-screen
            options.add_argument('--no-first-run')
            options.add_argument('--no-default-browser-check')
            self.progress_update.emit(f"Using real Chrome profile: {chrome_profile_path}")
        else:
            options.add_argument('--headless=new')

        if proxy:
            scheme = proxy_type.lower()
            options.add_argument(f'--proxy-server={scheme}://{proxy}')
            self.progress_update.emit(f"Selenium proxy: {scheme}://{proxy}")

        # Selenium Manager (Selenium 4.6+) auto-downloads the right ChromeDriver
        self.progress_update.emit("Starting browser...")
        driver = webdriver.Chrome(options=options)

        # Patch navigator.webdriver to False so basic JS bot checks fail
        driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
            'source': 'Object.defineProperty(navigator, "webdriver", {get: () => undefined})'
        })

        results = []
        try:
            self.progress_update.emit(f"Loading {url}...")
            driver.get(url)
            for _ in range(20):
                if self._stopped():
                    return []
                time.sleep(0.1)

            if selector_type == 'css':
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
            elif selector_type == 'xpath':
                elements = driver.find_elements(By.XPATH, selector)
            else:
                elements = []

            for elem in elements:
                if self._stopped():
                    break
                results.append({
                    'tag':       elem.tag_name,
                    'text':      elem.text,
                    'html':      elem.get_attribute('outerHTML'),
                    'url':       url,
                    'timestamp': datetime.now().isoformat(),
                })
        finally:
            driver.quit()

        return results

    # ------------------------------------------------------------------
    # Playwright + stealth scraping
    # ------------------------------------------------------------------
    def _ensure_chromium(self):
        """
        Ensure Playwright's Chromium binary is present.

        Sets PLAYWRIGHT_BROWSERS_PATH to a persistent, user-writable
        AppData folder so that:
          - The download lands somewhere the app can always write to
          - Chromium persists across launches and updates
          - Both the install command and sync_playwright() see the same path
        """
        import os as _os, sys as _sys, pathlib as _pl, subprocess

        # Point Playwright at a stable, writable user directory.
        # Must be set BEFORE any playwright import resolves browser paths.
        appdata = _os.environ.get("APPDATA", str(_pl.Path.home()))
        browsers_path = str(_pl.Path(appdata) / "Scraper of Death" / "browsers")
        _os.environ["PLAYWRIGHT_BROWSERS_PATH"] = browsers_path
        _pl.Path(browsers_path).mkdir(parents=True, exist_ok=True)

        # Check: try a quick headless launch
        try:
            with sync_playwright() as _p:
                _b = _p.chromium.launch(headless=True)
                _b.close()
            return   # Chromium is present
        except Exception as e:
            err = str(e)
            if "Executable doesn't exist" not in err and "BrowserType.launch" not in err:
                raise

        # Chromium is missing — download it
        self.progress_update.emit(
            f"Chromium not found — downloading to {browsers_path} (one-time, ~150 MB)..."
        )

        # Find the playwright node driver
        node_exe   = None
        cli_script = None

        # In a PyInstaller bundle, driver is in _internal/playwright/driver/
        if hasattr(_sys, "_MEIPASS"):
            driver_root = _pl.Path(_sys._MEIPASS) / "playwright" / "driver"
        else:
            driver_root = None

        # Also check next to the exe (one-dir builds)
        exe_dir = _pl.Path(_sys.executable).parent
        for root in filter(None, [
            driver_root,
            exe_dir / "_internal" / "playwright" / "driver",
            exe_dir / "playwright" / "driver",
        ]):
            n = root / "node.exe"
            if not n.exists():
                n = root / "node"
            if n.exists():
                node_exe = n
                for rel in [
                    "package/lib/cli/index.js",
                    "package/cli.js",
                    "package/index.js",
                ]:
                    s = root / rel.replace("/", _os.sep)
                    if s.exists():
                        cli_script = s
                        break
            if node_exe and cli_script:
                break

        # Fallback: use compute_driver_executable from the Python package
        if not node_exe or not cli_script:
            try:
                from playwright._impl._driver import compute_driver_executable
                node_exe, cli_script = compute_driver_executable()
            except Exception:
                pass

        self.progress_update.emit(
            f"Driver: {node_exe}  CLI: {cli_script}"
        )

        if not node_exe or not _pl.Path(str(node_exe)).exists():
            raise Exception(
                "Cannot locate Playwright node driver.\n"
                "Run manually: python -m playwright install chromium"
            )
        if not cli_script or not _pl.Path(str(cli_script)).exists():
            raise Exception(
                f"Cannot locate Playwright CLI script (checked {cli_script}).\n"
                "Run manually: python -m playwright install chromium"
            )

        env = _os.environ.copy()   # carries PLAYWRIGHT_BROWSERS_PATH
        cmd = [str(node_exe), str(cli_script), "install", "chromium"]
        self.progress_update.emit(f"CMD: {' '.join(cmd)}")

        try:
            # Stream output line-by-line into the app console so the user
            # sees download progress without any flashing terminal windows.
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,   # merge stderr into stdout
                text=True,
                env=env,
                creationflags=(
                    subprocess.CREATE_NO_WINDOW   # suppress console window on Windows
                    if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
                ),
            )
            for line in proc.stdout:
                line = line.rstrip()
                if line:
                    self.progress_update.emit(line)
                if self._stopped():
                    proc.terminate()
                    return []

            proc.wait(timeout=300)
            if proc.returncode == 0:
                self.progress_update.emit("✅ Chromium downloaded successfully.")
            else:
                raise Exception(f"Playwright exited with code {proc.returncode}")
        except subprocess.TimeoutExpired:
            proc.kill()
            raise Exception("Download timed out. Check internet connection.")
        except Exception as e:
            raise Exception(
                f"Chromium download failed: {e}\n\n"
                "Run manually: python -m playwright install chromium"
            )

    def _scrape_with_playwright(self, url: str, selector_type: str, selector: str,
                                 proxy: str = '', proxy_type: str = 'http',
                                 proxy_user: str = '', proxy_pass: str = '') -> List[Dict]:
        if not PLAYWRIGHT_AVAILABLE:
            raise Exception(
                "Playwright not installed.\n\n"
                "Run:\n"
                "  pip install playwright playwright-stealth\n"
                "  playwright install chromium"
            )

        # Auto-download Chromium if missing (first run on a new machine)
        self._ensure_chromium()

        proxy_config = None
        if proxy:
            scheme = proxy_type.lower()
            proxy_config = {'server': f'{scheme}://{proxy}'}
            if proxy_user:
                proxy_config['username'] = proxy_user
                proxy_config['password'] = proxy_pass
            self.progress_update.emit(f"Playwright proxy: {scheme}://{proxy}")

        stealth_active = PLAYWRIGHT_STEALTH
        self.progress_update.emit(
            "Starting Playwright" +
            (" + stealth" if stealth_active else " (install playwright-stealth for full stealth)") +
            "..."
        )

        results = []
        with sync_playwright() as p:
            launch_args = {'headless': True}
            if proxy_config:
                launch_args['proxy'] = proxy_config

            browser = p.chromium.launch(**launch_args)
            context = browser.new_context(
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                           'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080},
                locale='en-US',
                timezone_id='America/New_York',
                java_script_enabled=True,
            )
            page = context.new_page()

            if stealth_active and _stealth_instance is not None:
                # playwright-stealth 2.x: Stealth is a dataclass holding JS scripts.
                # Apply each script as a page init script directly.
                try:
                    for _script in _stealth_instance.enabled_scripts:
                        page.add_init_script(_script)
                except Exception as _se:
                    self.progress_update.emit(f"Stealth apply warning: {_se}")

            self.progress_update.emit(f"Loading {url}...")
            page.goto(url, wait_until='networkidle', timeout=30000)

            for _ in range(10):
                if self._stopped():
                    browser.close()
                    return []
                time.sleep(0.1)

            if selector_type == 'css':
                elements = page.query_selector_all(selector)
            elif selector_type == 'xpath':
                elements = page.query_selector_all(f'xpath={selector}')
            else:
                elements = []

            for elem in elements:
                if self._stopped():
                    break
                try:
                    tag  = elem.evaluate('el => el.tagName.toLowerCase()')
                    text = elem.inner_text()
                    html = elem.inner_html()
                    results.append({
                        'tag':       tag,
                        'text':      text.strip(),
                        'html':      html,
                        'url':       url,
                        'timestamp': datetime.now().isoformat(),
                    })
                except Exception:
                    continue

            browser.close()

        return results

    # ------------------------------------------------------------------
    # Link following
    # ------------------------------------------------------------------
    def _follow_links(self, initial_results: List[Dict], max_depth: int, delay: float) -> List[Dict]:
        """Follow href links found in scraped elements, checking stop flag between each."""
        all_results = list(initial_results)
        use_headers = self.config.get('use_headers', False)
        selector_type = self.config.get('selector_type', 'css')
        selector      = self.config.get('selector', '')

        links_to_follow = [
            r for r in initial_results if 'attr_href' in r
        ][:10]   # hard cap at 10

        for i, result in enumerate(links_to_follow):
            if self._stopped():
                self.progress_update.emit("Stop requested — halting link following.")
                break

            full_url = urljoin(result['url'], result['attr_href'])
            self.progress_update.emit(f"Following link {i+1}/{len(links_to_follow)}: {full_url}")

            # Interruptible delay — sleep in 0.1 s chunks
            elapsed = 0.0
            while elapsed < delay:
                if self._stopped():
                    return all_results
                time.sleep(0.1)
                elapsed += 0.1

            try:
                linked = self._scrape_with_requests(full_url, selector_type, selector, use_headers)
                all_results.extend(linked)
            except Exception as e:
                self.progress_update.emit(f"Error on {full_url}: {e}")

        return all_results

# =============================================================================
# Main Application Window
# =============================================================================

class ScraperOfDeath(QMainWindow):
    """Main application window for Scraper of Death."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{VERSION}")

        # Qt icon — shown in title bar and used as fallback
        icon_path = resource_path("icon.ico")
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))

        self.setMinimumSize(800, 600)
        self.resize(1200, 800)

        # State
        self.scraper_thread = None
        self.current_results = []

        # Setup UI
        self._setup_ui()
        self._apply_theme()

    def showEvent(self, event):
        """
        Override showEvent to set Win32 taskbar icon AFTER the window has a
        real HWND. winId() before show() returns a temporary handle that the
        shell ignores for taskbar purposes.
        """
        super().showEvent(event)
        if sys.platform == 'win32':
            QTimer.singleShot(0, self._set_win32_icon)

    def _set_win32_icon(self):
        """Set icon via Win32 API once the event loop is running."""
        try:
            import ctypes
            icon_path = resource_path("icon.ico")
            if not icon_path.exists():
                return

            hwnd = int(self.winId())

            # Load the icon at both shell (large) and small sizes
            LR_LOADFROMFILE  = 0x00000010
            LR_DEFAULTSIZE   = 0x00000040
            IMAGE_ICON       = 1
            WM_SETICON       = 0x0080
            ICON_SMALL       = 0
            ICON_BIG         = 1

            def load(cx, cy):
                return ctypes.windll.user32.LoadImageW(
                    None, str(icon_path), IMAGE_ICON, cx, cy, LR_LOADFROMFILE
                )

            big   = load(256, 256)
            small = load(16,  16)

            if big:
                ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG,   big)
                self._ico_big = big        # keep reference — prevents GC
            if small:
                ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, small)
                self._ico_small = small
        except Exception as e:
            print(f"Win32 icon error: {e}")
        
    def _setup_ui(self):
        """Setup the user interface."""
        # Create menu bar
        self._create_menu_bar()
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # Title — compact, fixed height
        title_label = QLabel(APP_NAME)
        title_label.setFont(QFont("Courier", 24, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setFixedHeight(50)
        layout.addWidget(title_label)

        # Tab widget fills all remaining vertical space
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, stretch=1)
        
        # Create tabs
        self._create_scraper_tab()
        self._create_results_tab()
        self._create_settings_tab()

        # Connect signals after all UI elements exist
        self.method_combo.currentIndexChanged.connect(self._on_method_changed)
        self.real_profile_check.toggled.connect(self._on_real_profile_toggled)
        
        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
    
    def _create_menu_bar(self):
        """Create the application menu bar."""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("&File")
        
        export_action = QAction("&Export Results", self)
        export_action.triggered.connect(self._export_results)
        file_menu.addAction(export_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Help menu
        help_menu = menubar.addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)
    
    def _create_scraper_tab(self):
        """Create the main scraper configuration tab."""
        tab = QWidget()
        tab_layout = QVBoxLayout(tab)
        tab_layout.setSpacing(0)
        tab_layout.setContentsMargins(0, 0, 0, 0)

        # --- Top/Bottom splitter: config vs console ---
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.setHandleWidth(6)
        splitter.setStyleSheet(f"""
            QSplitter::handle {{
                background-color: {GRAY_BORDER};
            }}
            QSplitter::handle:hover {{
                background-color: {GREEN_ACCENT};
            }}
        """)

        # ── Top pane: all config groups ──────────────────────────────────────
        top_widget = QWidget()
        # Prevent the top pane from expanding vertically on maximize —
        # the splitter's stretch factor handles distribution instead.
        top_widget.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Preferred
        )
        layout = QVBoxLayout(top_widget)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 6)

        # URL input group
        url_group = QGroupBox("Target URL")
        url_layout = QHBoxLayout()
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("https://example.com")
        self.url_input.setFont(QFont("Courier", 10))
        url_layout.addWidget(self.url_input)
        url_group.setLayout(url_layout)
        layout.addWidget(url_group)

        # Scraping method group
        method_group = QGroupBox("Scraping Method")
        method_layout = QVBoxLayout()

        method_row = QHBoxLayout()
        method_row.addWidget(QLabel("Method:"))
        self.method_combo = QComboBox()
        self.method_combo.addItems([
            "Requests (Fast)",
            "Selenium (JavaScript Support)",
            "Playwright (Stealth)",
        ])
        method_row.addWidget(self.method_combo)
        method_row.addStretch()
        method_layout.addLayout(method_row)

        self.use_headers_check = QCheckBox("Use Stealth Headers (Anti-Detection)")
        self.use_headers_check.setChecked(True)
        method_layout.addWidget(self.use_headers_check)

        # Real Chrome profile — only relevant for Selenium
        self.real_profile_check = QCheckBox("Use Real Chrome Profile (defeats most bot detection)")
        self.real_profile_check.setChecked(False)
        self.real_profile_check.setVisible(False)   # shown when Selenium selected
        self.real_profile_check.setToolTip(
            "Launches your actual Chrome browser (off-screen) with your real cookies,\n"
            "extensions, and fingerprint. Chrome must not be open already."
        )
        method_layout.addWidget(self.real_profile_check)

        self.chrome_profile_label = QLabel("Chrome Profile Path:")
        self.chrome_profile_label.setVisible(False)
        self.chrome_profile_input = QLineEdit()
        self.chrome_profile_input.setFont(QFont("Courier", 9))
        self.chrome_profile_input.setVisible(False)

        # Auto-fill the default Chrome profile path for the current OS
        import sys as _sys, os as _os
        if _sys.platform == 'win32':
            _default = _os.path.join(_os.environ.get('LOCALAPPDATA',''), 'Google', 'Chrome', 'User Data')
        elif _sys.platform == 'darwin':
            _default = _os.path.expanduser('~/Library/Application Support/Google/Chrome')
        else:
            _default = _os.path.expanduser('~/.config/google-chrome')
        self.chrome_profile_input.setText(_default)

        profile_row = QHBoxLayout()
        profile_row.addWidget(self.chrome_profile_label)
        profile_row.addWidget(self.chrome_profile_input)
        method_layout.addLayout(profile_row)

        method_group.setLayout(method_layout)
        layout.addWidget(method_group)

        # Selector group
        selector_group = QGroupBox("Element Selector")
        selector_layout = QVBoxLayout()

        selector_type_row = QHBoxLayout()
        selector_type_row.addWidget(QLabel("Selector Type:"))
        self.selector_type_combo = QComboBox()
        self.selector_type_combo.addItems(["CSS Selector", "XPath (Selenium only)", "Regex Pattern"])
        selector_type_row.addWidget(self.selector_type_combo)
        selector_type_row.addStretch()
        selector_layout.addLayout(selector_type_row)

        selector_input_row = QHBoxLayout()
        selector_input_row.addWidget(QLabel("Selector:"))
        self.selector_input = QLineEdit()
        self.selector_input.setPlaceholderText("Enter selector here (required)")
        self.selector_input.setFont(QFont("Courier", 9))
        selector_input_row.addWidget(self.selector_input)
        selector_layout.addLayout(selector_input_row)

        example_label = QLabel("Examples: div.content  |  //h1  |  <title>(.*?)</title>")
        example_label.setFont(QFont("Courier", 8))
        example_label.setStyleSheet(f"color: {GRAY_BORDER};")
        selector_layout.addWidget(example_label)

        selector_group.setLayout(selector_layout)
        layout.addWidget(selector_group)

        # Advanced options
        advanced_group = QGroupBox("Advanced Options")
        advanced_layout = QVBoxLayout()

        links_row = QHBoxLayout()
        self.follow_links_check = QCheckBox("Follow Links Found")
        links_row.addWidget(self.follow_links_check)
        links_row.addWidget(QLabel("Max Depth:"))
        self.max_depth_spin = QSpinBox()
        self.max_depth_spin.setRange(1, 5)
        self.max_depth_spin.setValue(1)
        links_row.addWidget(self.max_depth_spin)
        links_row.addStretch()
        advanced_layout.addLayout(links_row)

        delay_row = QHBoxLayout()
        delay_row.addWidget(QLabel("Delay Between Requests (seconds):"))
        self.delay_spin = QSpinBox()
        self.delay_spin.setRange(0, 10)
        self.delay_spin.setValue(1)
        delay_row.addWidget(self.delay_spin)
        delay_row.addStretch()
        advanced_layout.addLayout(delay_row)

        advanced_group.setLayout(advanced_layout)
        layout.addWidget(advanced_group)

        # Proxy group
        proxy_group = QGroupBox("Proxy (Optional)")
        proxy_layout = QVBoxLayout()

        proxy_row1 = QHBoxLayout()
        proxy_row1.addWidget(QLabel("Type:"))
        self.proxy_type_combo = QComboBox()
        self.proxy_type_combo.addItems(["http", "https", "socks5", "socks5h"])
        self.proxy_type_combo.setFixedWidth(100)
        proxy_row1.addWidget(self.proxy_type_combo)
        proxy_row1.addWidget(QLabel("  Host:Port:"))
        self.proxy_input = QLineEdit()
        self.proxy_input.setPlaceholderText("127.0.0.1:8080  or  leave blank to disable")
        self.proxy_input.setFont(QFont("Courier", 9))
        proxy_row1.addWidget(self.proxy_input)
        proxy_layout.addLayout(proxy_row1)

        proxy_row2 = QHBoxLayout()
        proxy_row2.addWidget(QLabel("Username:"))
        self.proxy_user_input = QLineEdit()
        self.proxy_user_input.setPlaceholderText("optional")
        self.proxy_user_input.setFixedWidth(160)
        proxy_row2.addWidget(self.proxy_user_input)
        proxy_row2.addWidget(QLabel("  Password:"))
        self.proxy_pass_input = QLineEdit()
        self.proxy_pass_input.setPlaceholderText("optional")
        self.proxy_pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.proxy_pass_input.setFixedWidth(160)
        proxy_row2.addWidget(self.proxy_pass_input)
        proxy_row2.addStretch()
        proxy_layout.addLayout(proxy_row2)

        proxy_note = QLabel("Tip: Tor daemon → socks5h + 127.0.0.1:9050  |  Tor Browser → socks5 + 127.0.0.1:9150")
        proxy_note.setFont(QFont("Courier", 8))
        proxy_note.setStyleSheet(f"color: {GRAY_BORDER};")
        proxy_layout.addWidget(proxy_note)

        proxy_group.setLayout(proxy_layout)
        layout.addWidget(proxy_group)

        # Control buttons (always at bottom of top pane)
        button_row = QHBoxLayout()
        self.start_button = QPushButton("⚡ START SCRAPING")
        self.start_button.setFont(QFont("Courier", 12, QFont.Weight.Bold))
        self.start_button.setMinimumHeight(50)
        self.start_button.clicked.connect(self._start_scraping)
        button_row.addWidget(self.start_button)

        self.stop_button = QPushButton("⬛ STOP")
        self.stop_button.setFont(QFont("Courier", 12, QFont.Weight.Bold))
        self.stop_button.setMinimumHeight(50)
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self._stop_scraping)
        button_row.addWidget(self.stop_button)

        layout.addLayout(button_row)

        # ── Bottom pane: resizable console ───────────────────────────────────
        console_group = QGroupBox("Console")
        console_layout = QVBoxLayout()
        console_layout.setContentsMargins(6, 6, 6, 6)
        self.console_output = QTextEdit()
        self.console_output.setReadOnly(True)
        self.console_output.setFont(QFont("Courier", 9))
        # No setMaximumHeight — let the splitter control it
        console_layout.addWidget(self.console_output)
        console_group.setLayout(console_layout)

        # Wrap the config pane in a scroll area so it never squashes
        scroll = QScrollArea()
        scroll.setWidget(top_widget)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setStyleSheet(f"""
            QScrollArea {{
                border: none;
                background-color: {DARK_BG};
            }}
            QScrollArea > QWidget > QWidget {{
                background-color: {DARK_BG};
            }}
            QScrollBar:vertical {{
                background: {DARKER_BG};
                width: 10px;
                border: none;
            }}
            QScrollBar::handle:vertical {{
                background: {GRAY_BORDER};
                border-radius: 5px;
                min-height: 20px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: {GREEN_ACCENT};
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
        """)
        scroll.viewport().setStyleSheet(f"background-color: {DARK_BG};")

        # Add both panes to splitter; default 70/30 split
        splitter.addWidget(scroll)
        splitter.addWidget(console_group)
        splitter.setStretchFactor(0, 7)
        splitter.setStretchFactor(1, 3)

        tab_layout.addWidget(splitter)
        self.tabs.addTab(tab, "⚙ Scraper")
    
    def _create_results_tab(self):
        """Create the results viewing tab."""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # Results info row
        info_row = QHBoxLayout()
        self.results_label = QLabel("Results: 0 items")
        self.results_label.setFont(QFont("Courier", 10, QFont.Weight.Bold))
        info_row.addWidget(self.results_label)
        info_row.addStretch()

        clear_button = QPushButton("Clear Results")
        clear_button.clicked.connect(self._clear_results)
        info_row.addWidget(clear_button)

        export_button = QPushButton("Export Results")
        export_button.clicked.connect(self._export_results)
        info_row.addWidget(export_button)

        layout.addLayout(info_row)

        # Results table — expands to fill all remaining space
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(5)
        self.results_table.setHorizontalHeaderLabels(["Tag", "Text", "URL", "Timestamp", "HTML"])
        self.results_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.results_table.horizontalHeader().setStretchLastSection(True)
        self.results_table.setAlternatingRowColors(True)
        layout.addWidget(self.results_table, stretch=1)

        self.tabs.addTab(tab, "📊 Results")
    
    def _create_settings_tab(self):
        """Create the settings tab."""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Dependencies status
        deps_group = QGroupBox("Dependencies Status")
        deps_layout = QVBoxLayout()
        
        requests_status = "✅ Installed" if REQUESTS_AVAILABLE else "❌ Not Installed"
        selenium_status = "✅ Installed" if SELENIUM_AVAILABLE else "❌ Not Installed"
        playwright_stealth_status = "✅ Active" if PLAYWRIGHT_STEALTH else f"❌ Inactive — {globals().get('_STEALTH_ERROR', 'not installed')}"
        
        deps_layout.addWidget(QLabel(f"Requests + BeautifulSoup4: {requests_status}"))
        deps_layout.addWidget(QLabel(f"playwright-stealth: {playwright_stealth_status}"))
        deps_layout.addWidget(QLabel(f"Selenium: {selenium_status}"))
        
        if not REQUESTS_AVAILABLE or not SELENIUM_AVAILABLE:
            install_label = QLabel("\nInstall missing dependencies:")
            install_label.setFont(QFont("Courier", 9, QFont.Weight.Bold))
            deps_layout.addWidget(install_label)
            
            if not REQUESTS_AVAILABLE:
                deps_layout.addWidget(QLabel("  pip install requests beautifulsoup4 lxml"))
            if not SELENIUM_AVAILABLE:
                deps_layout.addWidget(QLabel("  pip install selenium"))
        
        deps_group.setLayout(deps_layout)
        layout.addWidget(deps_group)
        
        # About
        about_group = QGroupBox("About")
        about_layout = QVBoxLayout()
        about_layout.addWidget(QLabel(f"{APP_NAME} v{VERSION}"))
        about_layout.addWidget(QLabel(ORG_NAME))
        about_layout.addWidget(QLabel("\nAdvanced web scraping tool with:"))
        about_layout.addWidget(QLabel("• Multiple scraping methods (Requests/Selenium)"))
        about_layout.addWidget(QLabel("• CSS, XPath, and Regex selectors"))
        about_layout.addWidget(QLabel("• Anti-detection headers"))
        about_layout.addWidget(QLabel("• Link following with depth control"))
        about_layout.addWidget(QLabel("• Export to JSON, CSV, SQLite"))
        
        
        about_group.setLayout(about_layout)
        layout.addWidget(about_group)
        
        layout.addStretch()
        
        self.tabs.addTab(tab, "⚙ Settings")
    
    def _apply_theme(self):
        """Apply dark theme to the application."""
        palette = QPalette()
        
        # Window
        palette.setColor(QPalette.ColorRole.Window, QColor(DARK_BG))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(LIGHT_TEXT))
        
        # Base (text input backgrounds)
        palette.setColor(QPalette.ColorRole.Base, QColor(DARKER_BG))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(DARK_BG))
        palette.setColor(QPalette.ColorRole.Text, QColor(LIGHT_TEXT))
        
        # Buttons
        palette.setColor(QPalette.ColorRole.Button, QColor(GRAY_BORDER))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(LIGHT_TEXT))
        
        # Highlights
        palette.setColor(QPalette.ColorRole.Highlight, QColor(GREEN_ACCENT))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(DARKER_BG))
        
        self.setPalette(palette)
        
        # Custom stylesheet for specific widgets
        self.setStyleSheet(f"""
            QMainWindow {{
                background-color: {DARK_BG};
            }}
            QLabel {{
                color: {LIGHT_TEXT};
            }}
            QGroupBox {{
                color: {GREEN_ACCENT};
                border: 2px solid {GRAY_BORDER};
                border-radius: 5px;
                margin-top: 10px;
                font-weight: bold;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }}
            QPushButton {{
                background-color: {GRAY_BORDER};
                color: {LIGHT_TEXT};
                border: 2px solid {GREEN_ACCENT};
                border-radius: 5px;
                padding: 8px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {GREEN_ACCENT};
                color: {DARKER_BG};
            }}
            QPushButton:pressed {{
                background-color: {DARKER_BG};
            }}
            QPushButton:disabled {{
                background-color: {DARKER_BG};
                color: {GRAY_BORDER};
                border-color: {GRAY_BORDER};
            }}
            QLineEdit, QTextEdit, QComboBox, QSpinBox {{
                background-color: {DARKER_BG};
                color: {LIGHT_TEXT};
                border: 1px solid {GRAY_BORDER};
                border-radius: 3px;
                padding: 5px;
            }}
            QComboBox QAbstractItemView {{
                background-color: {DARKER_BG};
                color: {LIGHT_TEXT};
                selection-background-color: {GREEN_ACCENT};
                selection-color: {DARKER_BG};
                border: 1px solid {GRAY_BORDER};
                outline: none;
            }}
            QComboBox::drop-down {{
                border: none;
            }}
            QComboBox::down-arrow {{
                width: 12px;
                height: 12px;
            }}
            QTableWidget {{
                background-color: {DARKER_BG};
                color: {LIGHT_TEXT};
                gridline-color: {GRAY_BORDER};
                border: 1px solid {GRAY_BORDER};
                alternate-background-color: {DARK_BG};
            }}
            QTableWidget::item {{
                background-color: {DARKER_BG};
                color: {LIGHT_TEXT};
            }}
            QTableWidget::item:alternate {{
                background-color: {DARK_BG};
                color: {LIGHT_TEXT};
            }}
            QTableWidget::item:selected {{
                background-color: {GREEN_ACCENT};
                color: {DARKER_BG};
            }}
            QTableWidget::item:selected:alternate {{
                background-color: {GREEN_ACCENT};
                color: {DARKER_BG};
            }}
            QHeaderView::section {{
                background-color: {GRAY_BORDER};
                color: {GREEN_ACCENT};
                padding: 5px;
                border: 1px solid {DARKER_BG};
                font-weight: bold;
            }}
            QTabWidget::pane {{
                border: 2px solid {GRAY_BORDER};
                border-radius: 5px;
            }}
            QTabBar::tab {{
                background-color: {GRAY_BORDER};
                color: {LIGHT_TEXT};
                padding: 8px 16px;
                margin: 2px;
                border-radius: 3px;
            }}
            QTabBar::tab:selected {{
                background-color: {GREEN_ACCENT};
                color: {DARKER_BG};
                font-weight: bold;
            }}
            QCheckBox {{
                color: {LIGHT_TEXT};
            }}
            QCheckBox::indicator:checked {{
                background-color: {GREEN_ACCENT};
                border: 1px solid {GREEN_ACCENT};
            }}
            QMenuBar {{
                background-color: {DARKER_BG};
                color: {LIGHT_TEXT};
            }}
            QMenuBar::item:selected {{
                background-color: {GREEN_ACCENT};
                color: {DARKER_BG};
            }}
            QMenu {{
                background-color: {DARK_BG};
                color: {LIGHT_TEXT};
                border: 1px solid {GRAY_BORDER};
            }}
            QMenu::item:selected {{
                background-color: {GREEN_ACCENT};
                color: {DARKER_BG};
            }}
            QStatusBar {{
                background-color: {DARKER_BG};
                color: {GREEN_ACCENT};
            }}
            QMessageBox {{
                background-color: {LIGHT_TEXT};
            }}
            QMessageBox QLabel {{
                color: #000000;
                background-color: {LIGHT_TEXT};
            }}
            QMessageBox QPushButton {{
                background-color: {GRAY_BORDER};
                color: {LIGHT_TEXT};
                border: 2px solid {GREEN_ACCENT};
                min-width: 80px;
            }}
            QMessageBox QPushButton:hover {{
                background-color: {GREEN_ACCENT};
                color: #000000;
            }}
        """)
    
    def _log(self, message: str):
        """Add message to console output."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.console_output.append(f"[{timestamp}] {message}")
        self.console_output.moveCursor(QTextCursor.MoveOperation.End)
    
    def _on_method_changed(self, index: int):
        """Show/hide real Chrome profile controls when Selenium is selected."""
        is_selenium = (index == 1)
        self.real_profile_check.setVisible(is_selenium)
        visible = is_selenium and self.real_profile_check.isChecked()
        self.chrome_profile_label.setVisible(visible)
        self.chrome_profile_input.setVisible(visible)

    def _on_real_profile_toggled(self, checked: bool):
        """Show/hide Chrome profile path input when checkbox is toggled."""
        is_selenium = (self.method_combo.currentIndex() == 1)
        visible = is_selenium and checked
        self.chrome_profile_label.setVisible(visible)
        self.chrome_profile_input.setVisible(visible)

    def _start_scraping(self):
        """Start the scraping operation."""
        url = self.url_input.text().strip()
        
        if not url:
            QMessageBox.warning(self, "Error", "Please enter a URL")
            return
        
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
            self.url_input.setText(url)
        
        # Get selector type first
        selector_type_text = self.selector_type_combo.currentText()
        if 'CSS' in selector_type_text:
            selector_type = 'css'
        elif 'XPath' in selector_type_text:
            selector_type = 'xpath'
        else:
            selector_type = 'regex'
        
        # Get selector and validate
        selector = self.selector_input.text().strip()
        
        # Check if selector is empty
        if not selector:
            QMessageBox.warning(
                self, 
                "Missing Selector", 
                "Please enter a selector to specify what elements to scrape.\n\n"
                "Examples:\n"
                "• CSS: div.content, h1.title, a[href]\n"
                "• XPath: //div[@class='content'], //h1\n"
                "• Regex: <title>(.*?)</title>"
            )
            return
        
        # Check for CSS selector accidentally typed in XPath field
        if selector_type == 'xpath':
            if selector and not selector.strip().startswith(('/', '(', '.')):
                QMessageBox.warning(
                    self,
                    "XPath Selector Format",
                    f"This looks like a CSS selector, not XPath:\n  {selector}\n\n"
                    "XPath expressions must start with // or /\n\n"
                    "CSS equivalent examples:\n"
                    f"  CSS:   span.titleline > a\n"
                    f"  XPath: //span[@class='titleline']/a\n\n"
                    "Switch the Selector Type to CSS Selector, or enter a valid XPath."
                )
                return

        # Check for common invalid characters in CSS selectors
        if selector_type == 'css':
            # Catch URL accidentally entered in selector field
            if selector.startswith(('http://', 'https://', 'www.')):
                QMessageBox.warning(
                    self,
                    "URL in Selector Field",
                    f"It looks like you entered a URL in the Selector field:\n{selector}\n\n"
                    "The Selector field should contain a CSS pattern, not a URL.\n\n"
                    "Examples:\n"
                    "\u2022 span.titleline > a\n"
                    "\u2022 div.content\n"
                    "\u2022 h1, h2, h3"
                )
                return

            # Check for backticks, smart quotes, or other problematic characters
            invalid_chars = ['`', '‘', '’', '“', '”', '´', '′']
            found_invalid = [char for char in invalid_chars if char in selector]
            if found_invalid:
                QMessageBox.warning(
                    self,
                    "Invalid Characters in Selector",
                    f"Your selector contains invalid characters: {', '.join(found_invalid)}\n\n"
                    f"Current selector: {selector}\n\n"
                    "Please use only standard ASCII characters:\n"
                    "\u2022 Single quotes: '\n"
                    "\u2022 Double quotes: \"\n"
                    "\u2022 Regular punctuation"
                )
                return
        
        # Get configuration
        method_text = self.method_combo.currentText()
        if 'Requests' in method_text:
            method = 'requests'
        elif 'Playwright' in method_text:
            method = 'playwright'
        else:
            method = 'selenium'

        config = {
            'url':                 url,
            'method':              method,
            'selector_type':       selector_type,
            'selector':            selector,
            'use_headers':         self.use_headers_check.isChecked(),
            'follow_links':        self.follow_links_check.isChecked(),
            'max_depth':           self.max_depth_spin.value(),
            'delay':               self.delay_spin.value(),
            'proxy':               self.proxy_input.text().strip(),
            'proxy_type':          self.proxy_type_combo.currentText(),
            'proxy_user':          self.proxy_user_input.text().strip(),
            'proxy_pass':          self.proxy_pass_input.text(),
            'real_profile':        self.real_profile_check.isChecked(),
            'chrome_profile_path': self.chrome_profile_input.text().strip(),
        }
        
        # Check dependencies
        if method == 'requests' and not REQUESTS_AVAILABLE:
            QMessageBox.warning(
                self,
                "Missing Dependencies",
                "Requests method requires: pip install requests beautifulsoup4 lxml"
            )
            return
        
        if method == 'selenium' and not SELENIUM_AVAILABLE:
            QMessageBox.warning(
                self,
                "Missing Dependencies",
                "Selenium method requires:\n  pip install selenium\n\n"
                "ChromeDriver is managed automatically by Selenium 4.6+."
            )
            return

        if method == 'playwright' and not PLAYWRIGHT_AVAILABLE:
            QMessageBox.warning(
                self,
                "Missing Dependencies",
                "Playwright method requires:\n"
                "  pip install playwright playwright-stealth\n"
                "  playwright install chromium\n\n"
                "playwright-stealth is optional but strongly recommended."
            )
            return

        # Start scraping
        self._log("=" * 60)
        proxy_str = config.get('proxy', '')
        self._log(f"Starting scrape: {url}")
        self._log(f"Method: {method}  |  Selector: {selector_type}"
                  + (f"  |  Proxy: {config['proxy_type']}://{proxy_str}" if proxy_str else ""))
        
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status_bar.showMessage("Scraping...")
        
        self.scraper_thread = ScraperThread(config)
        self.scraper_thread.progress_update.connect(self._log)
        self.scraper_thread.scrape_complete.connect(self._on_scrape_complete)
        self.scraper_thread.error_occurred.connect(self._on_scrape_error)
        self.scraper_thread.start()
    
    def _stop_scraping(self):
        """Stop the current scraping operation without blocking the UI."""
        if self.scraper_thread and self.scraper_thread.isRunning():
            self._log("Stop requested — will finish after current request...")
            self.scraper_thread.stop()
            # Do NOT call wait() — it blocks the main thread and causes "Not Responding".
            # The thread emits scrape_complete when done, which re-enables buttons.

        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_bar.showMessage("Stopping...")
    
    def _on_scrape_complete(self, results: List[Dict]):
        """Handle scraping completion."""
        self.current_results = results
        self._update_results_table()
        
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_bar.showMessage(f"Complete - {len(results)} results")
        
        # Switch to results tab
        self.tabs.setCurrentIndex(1)
    
    def _on_scrape_error(self, error: str):
        """Handle scraping errors."""
        # Strip Selenium's multi-line stack trace — keep only the first
        # meaningful line so the log and dialog stay readable.
        clean = error
        for marker in ("Stacktrace:", "\nFor documentation on this error"):
            if marker in clean:
                clean = clean[:clean.index(marker)].strip()
        # Also strip the leading "Message: " prefix Selenium adds
        if clean.startswith("Message: "):
            clean = clean[len("Message: "):]
        self._log(f"ERROR: {clean}")
        error = clean   # use cleaned version for classifier below
        
        # Parse error for better user messages
        error_title = "Scraping Error"
        user_message = error
        
        e = error.lower()

        if "no module named" in e and "selenium" in e:
            error_title = "Selenium Not Installed"
            user_message = (
                "The Selenium library is not installed.\n\n"
                "Run:\n  pip install selenium\n\n"
                "ChromeDriver is managed automatically — no manual download needed."
            )
        elif "no module named" in e and "playwright" in e:
            error_title = "Playwright Not Installed"
            user_message = (
                "Playwright is not installed.\n\n"
                "Run:\n"
                "  pip install playwright playwright-stealth\n"
                "  playwright install chromium"
            )
        elif "invalid selector" in e and "xpath" in e:
            error_title = "CSS Selector Used as XPath"
            user_message = (
                "You entered a CSS selector in the XPath field.\n\n"
                "XPath must start with // or /\n\n"
                "Example — to convert your selector:\n"
                "  CSS:   span.titleline > a\n"
                "  XPath: //span[@class='titleline']/a\n\n"
                "Either switch Selector Type to CSS Selector, "
                "or enter a valid XPath expression."
            )
        elif "invalid selector" in e:
            error_title = "Invalid Selector"
            user_message = "The selector syntax is invalid.\n\nPlease check your selector and try again."
        elif "no selector specified" in e:
            error_title = "No Selector"
            user_message = "Please enter a selector to specify what elements to scrape."
        elif "user data directory is already in use" in e or "singletonlock" in e or "profile" in e and "in use" in e:
            error_title = "Chrome Profile In Use"
            user_message = (
                "The Chrome profile is locked by a running Chrome window.\n\n"
                "Close ALL Chrome windows completely, then try again.\n\n"
                "If Chrome is not open, delete this file and retry:\n"
                "  ...\\Chrome\\User Data\\SingletonLock"
            )
        elif "no symbol" in e or ("chromedriver" in e and ("crash" in e or "exit" in e or "symbol" in e)):
            error_title = "ChromeDriver Crashed"
            user_message = (
                "ChromeDriver crashed — most likely because Chrome is still open.\n\n"
                "Fix:\n"
                "  1. Close ALL Chrome windows completely\n"
                "  2. Wait a few seconds\n"
                "  3. Try again\n\n"
                "If Chrome is closed and this keeps happening, run:\n"
                "  pip install --upgrade selenium"
            )
        elif "session not created" in e or ("executable" in e and "path" in e):
            error_title = "Chrome Launch Failed"
            user_message = (
                "Selenium could not start Chrome.\n\n"
                "• Make sure Google Chrome is installed\n"
                "• Run: pip install --upgrade selenium\n"
                "  (Selenium 4.6+ manages ChromeDriver automatically)"
            )
        elif "timeout" in e or "timed out" in e:
            error_title = "Timeout"
            user_message = "Request timed out. The server took too long to respond."
        elif "connection" in e or "refused" in e or "unreachable" in e:
            error_title = "Connection Error"
            user_message = "Could not connect to the URL. Check your internet connection."
        elif "403" in error or "forbidden" in e:
            error_title = "Access Forbidden"
            user_message = "The website blocked the request. Try enabling Stealth Headers."
        elif "404" in error:
            error_title = "Page Not Found"
            user_message = "The URL does not exist (404 error)."
        
        QMessageBox.critical(self, error_title, user_message)
        
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_bar.showMessage("Error")
    
    def _update_results_table(self):
        """Update the results table with current results."""
        self.results_table.setRowCount(0)
        self.results_label.setText(f"Results: {len(self.current_results)} items")
        
        for row, result in enumerate(self.current_results):
            self.results_table.insertRow(row)
            
            # Tag
            tag = result.get('tag', result.get('content', 'N/A'))
            self.results_table.setItem(row, 0, QTableWidgetItem(str(tag)))
            
            # Text (truncated)
            text = result.get('text', result.get('content', ''))
            if len(text) > 100:
                text = text[:100] + "..."
            self.results_table.setItem(row, 1, QTableWidgetItem(text))
            
            # URL
            self.results_table.setItem(row, 2, QTableWidgetItem(result.get('url', '')))
            
            # Timestamp
            timestamp = result.get('timestamp', '')
            if timestamp:
                timestamp = datetime.fromisoformat(timestamp).strftime("%Y-%m-%d %H:%M:%S")
            self.results_table.setItem(row, 3, QTableWidgetItem(timestamp))
            
            # HTML (truncated)
            html = result.get('html', '')
            if len(html) > 200:
                html = html[:200] + "..."
            self.results_table.setItem(row, 4, QTableWidgetItem(html))
    
    def _clear_results(self):
        """Clear all results."""
        reply = QMessageBox.question(
            self,
            "Clear Results",
            "Are you sure you want to clear all results?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.current_results = []
            self._update_results_table()
            self._log("Results cleared")
    
    def _export_results(self):
        """Export results to file."""
        if not self.current_results:
            QMessageBox.information(self, "No Results", "No results to export")
            return
        
        # Ask for format
        format_dialog = QMessageBox()
        format_dialog.setWindowTitle("Export Format")
        format_dialog.setText("Choose export format:")
        json_button = format_dialog.addButton("JSON", QMessageBox.ButtonRole.AcceptRole)
        csv_button = format_dialog.addButton("CSV", QMessageBox.ButtonRole.AcceptRole)
        sqlite_button = format_dialog.addButton("SQLite", QMessageBox.ButtonRole.AcceptRole)
        format_dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        format_dialog.exec()
        
        clicked = format_dialog.clickedButton()
        
        if clicked == json_button:
            self._export_json()
        elif clicked == csv_button:
            self._export_csv()
        elif clicked == sqlite_button:
            self._export_sqlite()
    
    def _export_json(self):
        """Export results to JSON."""
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export as JSON",
            f"scraper_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            "JSON Files (*.json)"
        )
        
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(self.current_results, f, indent=2, ensure_ascii=False)
                self._log(f"Results exported to {filename}")
                QMessageBox.information(self, "Success", f"Exported to {filename}")
            except Exception as e:
                QMessageBox.critical(self, "Export Error", str(e))
    
    def _export_csv(self):
        """Export results to CSV."""
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export as CSV",
            f"scraper_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            "CSV Files (*.csv)"
        )
        
        if filename:
            try:
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    if self.current_results:
                        # Get all unique keys
                        fieldnames = set()
                        for result in self.current_results:
                            fieldnames.update(result.keys())
                        fieldnames = sorted(list(fieldnames))
                        
                        writer = csv.DictWriter(f, fieldnames=fieldnames)
                        writer.writeheader()
                        writer.writerows(self.current_results)
                
                self._log(f"Results exported to {filename}")
                QMessageBox.information(self, "Success", f"Exported to {filename}")
            except Exception as e:
                QMessageBox.critical(self, "Export Error", str(e))
    
    def _export_sqlite(self):
        """Export results to SQLite database."""
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export as SQLite",
            f"scraper_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db",
            "SQLite Database (*.db)"
        )
        
        if filename:
            try:
                conn = sqlite3.connect(filename)
                cursor = conn.cursor()
                
                # Create table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS scrape_results (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        tag TEXT,
                        text TEXT,
                        html TEXT,
                        url TEXT,
                        timestamp TEXT,
                        data JSON
                    )
                """)
                
                # Insert results
                for result in self.current_results:
                    cursor.execute("""
                        INSERT INTO scrape_results (tag, text, html, url, timestamp, data)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (
                        result.get('tag', ''),
                        result.get('text', ''),
                        result.get('html', ''),
                        result.get('url', ''),
                        result.get('timestamp', ''),
                        json.dumps(result)
                    ))
                
                conn.commit()
                conn.close()
                
                self._log(f"Results exported to {filename}")
                QMessageBox.information(self, "Success", f"Exported to {filename}")
            except Exception as e:
                QMessageBox.critical(self, "Export Error", str(e))
    
    def _show_about(self):
        """Show about dialog."""
        QMessageBox.about(
            self,
            f"About {APP_NAME}",
            f"""<h2>{APP_NAME}</h2>
            <p>Version {VERSION}</p>
            <p>{ORG_NAME}</p>
            <br>
            <p>Advanced web scraping tool with support for:</p>
            <ul>
            <li>Multiple scraping methods (Requests/Selenium)</li>
            <li>CSS, XPath, and Regex selectors</li>
            <li>Anti-detection headers</li>
            <li>Link following with depth control</li>
            <li>Export to JSON, CSV, SQLite</li>
            </ul>
            """
        )

# =============================================================================
# Main Entry Point
# =============================================================================

def _install_linux_desktop():
    """
    Write a .desktop file and copy the icon so the Linux taskbar shows
    the correct skull icon. Called once at startup on Linux.
    """
    import shutil, subprocess
    exe = (sys.argv[0] if getattr(sys, 'frozen', False) else sys.executable)
    exe = str(Path(exe).resolve())

    app_dir  = Path.home() / ".local" / "share" / "applications"
    icon_dir = Path.home() / ".local" / "share" / "icons" / "hicolor" / "256x256" / "apps"
    app_dir.mkdir(parents=True, exist_ok=True)
    icon_dir.mkdir(parents=True, exist_ok=True)

    src_ico = resource_path("icon.ico")
    dst_ico = icon_dir / "scraper-of-death.ico"
    if src_ico.exists() and not dst_ico.exists():
        shutil.copy2(str(src_ico), str(dst_ico))

    desktop = app_dir / "scraper-of-death.desktop"
    desktop.write_text(
        f"[Desktop Entry]\nVersion=1.0\nType=Application\n"
        f"Name={APP_NAME}\nComment=Advanced Web Scraping Tool\n"
        f"Exec={exe}\nIcon={dst_ico}\nTerminal=false\n"
        f"Categories=Utility;Network;\n"
        f"StartupWMClass=scraper-of-death\nStartupNotify=true\n"
    )
    desktop.chmod(0o755)
    try:
        subprocess.run(["update-desktop-database", str(app_dir)],
                       check=False, capture_output=True)
    except FileNotFoundError:
        pass


def main():
    """Main application entry point."""
    import os

    # Linux: force X11/XCB backend — Wayland does not allow apps to
    # resize or maximize their own windows; XCB gives full WM control.
    # Must be set before QApplication is created.
    if sys.platform.startswith('linux') and 'QT_QPA_PLATFORM' not in os.environ:
        os.environ['QT_QPA_PLATFORM'] = 'xcb'

    # Windows: set AppUserModelID before QApplication for taskbar icon
    if sys.platform == 'win32':
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                'DeathsHeadSoftware.ScraperOfDeath.1.0.0'
            )
        except Exception:
            pass

    # Linux: install .desktop + icon, then bind this process to it
    if sys.platform.startswith('linux'):
        _install_linux_desktop()

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    if sys.platform.startswith('linux'):
        app.setDesktopFileName('scraper-of-death')

    icon_path = resource_path("icon.ico")
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # Build main window now (hidden). This lets the WM negotiate its
    # geometry and decorations before it is ever shown to the user.
    window = ScraperOfDeath()

    splash = create_splash()
    if splash:
        messages = [
            "Initializing scraper engine...",
            "Loading dependencies...",
            "Configuring anti-detection...",
            "Setting up selectors...",
            "Almost ready...",
        ]
        interval_ms = int(5500 / len(messages))
        idx = [0]

        def _tick():
            """Called every interval by QTimer - never blocks the event loop."""
            if idx[0] < len(messages):
                splash.showMessage(
                    "\n\n\n\n\n\n\n" + messages[idx[0]],
                    Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                    QColor(255, 255, 255),
                )
                idx[0] += 1
            else:
                _timer.stop()
                window.showNormal()
                window.raise_()
                window.activateWindow()
                splash.finish(window)

        splash.show()
        app.processEvents()

        _timer = QTimer()
        _timer.timeout.connect(_tick)
        _timer.start(interval_ms)
        _tick()
    else:
        window.showNormal()
        window.raise_()
        window.activateWindow()

    sys.exit(app.exec())


if __name__ == '__main__':
    main()
