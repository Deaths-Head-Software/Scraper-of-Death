@echo off
:: Scraper of Death — Windows Icon Cache Cleaner
:: Run as Administrator

echo Clearing Windows icon cache...
taskkill /f /im explorer.exe >nul 2>&1

del /f /q "%localappdata%\IconCache.db" >nul 2>&1
del /f /q "%localappdata%\Microsoft\Windows\Explorer\iconcache*" >nul 2>&1
del /f /q "%localappdata%\Microsoft\Windows\Explorer\thumbcache*" >nul 2>&1

echo Restarting Explorer...
start explorer.exe
echo Done. The skull icon should now appear in the taskbar.
pause
