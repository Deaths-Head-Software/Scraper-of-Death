#!/usr/bin/env python3
"""
Build script for Scraper of Death
Creates standalone executables using PyInstaller
Supports Windows, macOS, and Linux
"""
import sys, platform, subprocess, shutil
from pathlib import Path

APP_NAME    = "Scraper of Death"
MAIN_SCRIPT = "scraper_of_death.py"
ICON_FILE   = "icon.ico"

def build():
    print(f"Building {APP_NAME}...")
    print(f"Platform : {platform.system()} {platform.release()}")
    print(f"Python   : {sys.version.split()[0]}")

    try:
        import PyInstaller
        print(f"PyInstaller: {PyInstaller.__version__}")
    except ImportError:
        print("ERROR: PyInstaller not installed. Run: pip install pyinstaller")
        return False

    sep = ";" if platform.system() == "Windows" else ":"

    for path in ["build", "dist", f"{APP_NAME}.spec"]:
        p = Path(path)
        if p.exists():
            shutil.rmtree(p) if p.is_dir() else p.unlink()
            print(f"Cleaned: {path}")

    cmd = [
        "pyinstaller",
        "--onefile",
        "--windowed",
        f"--name={APP_NAME}",
        f"--icon={ICON_FILE}",
        "--add-data", f"splash.png{sep}.",
        "--add-data", f"icon.ico{sep}.",
        "--clean",
        "--noconfirm",
    ]

    if platform.system() == "Windows":
        for extra in ["scraper_of_death.manifest", "version_info.txt"]:
            if Path(extra).exists():
                flag = "--manifest" if "manifest" in extra else "--version-file"
                cmd.extend([f"{flag}={extra}"])
        cmd.extend(["--win-private-assemblies", "--win-no-prefer-redirects"])

    cmd.append(MAIN_SCRIPT)

    print("\nRunning:", " ".join(cmd), "\n")
    result = subprocess.run(cmd)

    if result.returncode == 0:
        dist = Path("dist")
        exe  = dist / (f"{APP_NAME}.exe" if platform.system() == "Windows" else APP_NAME)
        print(f"\n✅ Build successful!")
        if exe.exists():
            print(f"Executable : {exe.absolute()}")
            print(f"Size       : {exe.stat().st_size / 1_048_576:.1f} MB")
            if platform.system() == "Linux":
                exe.chmod(0o755)
                _write_linux_installer(exe)
        return True
    else:
        print(f"\n❌ Build failed (code {result.returncode})")
        return False

def _write_linux_installer(exe: Path):
    script = Path("dist") / "install_linux.sh"
    script.write_text(f"""#!/bin/bash
# Scraper of Death — Linux Installer
set -e
BIN="$HOME/.local/bin"
DES="$HOME/.local/share/applications"
ICO="$HOME/.local/share/icons/hicolor/256x256/apps"
mkdir -p "$BIN" "$DES" "$ICO"
cp "{exe.absolute()}" "$BIN/scraper-of-death"
chmod +x "$BIN/scraper-of-death"
cp "$(dirname "{exe.absolute()}")/icon.ico" "$ICO/scraper-of-death.ico" 2>/dev/null || true
cat > "$DES/scraper-of-death.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name={APP_NAME}
Comment=Advanced Web Scraping Tool
Exec=$BIN/scraper-of-death
Icon=$ICO/scraper-of-death.ico
Terminal=false
Categories=Utility;Network;
StartupWMClass=scraper-of-death
StartupNotify=true
EOF
chmod +x "$DES/scraper-of-death.desktop"
update-desktop-database "$DES" 2>/dev/null || true
echo "✅ Installed. Launch with: scraper-of-death"
""")
    script.chmod(0o755)
    print(f"Linux installer: {script.absolute()}")
    print("To install: bash dist/install_linux.sh")

if __name__ == "__main__":
    sys.exit(0 if build() else 1)
